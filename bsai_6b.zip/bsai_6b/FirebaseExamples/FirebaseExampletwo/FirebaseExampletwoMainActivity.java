package com.example.bsai_6b.FirebaseExamples.FirebaseExampletwo;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.ViewGroup;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.bsai_6b.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class FirebaseExampletwoMainActivity extends AppCompatActivity {
    DatabaseReference reference;
    RecyclerView recyclerView;
    FirebaseDatabase database;
    ArrayList<Student_BSAI>studentList;
    AdapterFirebase adapter;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_firebase_exampletwo_main);
        recyclerView= findViewById((R.id.firebaserecyclerview));
        LinearLayoutManager layoutManager= new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        FirebaseDatabase database= FirebaseDatabase.getInstance("https://bsaib-565d2-default-rtdb.firebaseio.com/");
        reference=database.getReference("BSAI");
        studentList= new ArrayList<>();
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
    private void FetchRecord (){
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (studentList!=null){
                    studentList.clear();
                    if (adapter!= null){
                        adapter.notifyDataSetChanged();
                    }
                }
                for (DataSnapshot dataSnapshot : snapshot.getChildren()){
                    Student_BSAI obj= new Student_BSAI();
                    obj.setName(dataSnapshot.child("Name").getValue().toString());
                    obj.setName(dataSnapshot.child("Picture").getValue().toString());
                    studentList.add(obj);

                }

                adapter=new AdapterFirebase(studentList, getApplicationContext());
                recyclerView.setAdapter(adapter);
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

}