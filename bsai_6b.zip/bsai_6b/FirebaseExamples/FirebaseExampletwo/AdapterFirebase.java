package com.example.bsai_6b.FirebaseExamples.FirebaseExampletwo;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.bsai_6b.R;

import java.util.ArrayList;

public class AdapterFirebase extends RecyclerView.Adapter<AdapterFirebase.ViewHolder> {


    ArrayList <Student_BSAI> studentList;
    Context context;

    public AdapterFirebase(ArrayList<Student_BSAI> studentList, Context applicationContext) {
    }

    public ArrayList<Student_BSAI> getStudentList() {
        return studentList;
    }

    public void setStudentList(ArrayList<Student_BSAI> studentList) {
        this.studentList = studentList;
    }

    public Context getContext() {
        return context;
    }

    public void setContext(Context context) {
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.firebasebsailayout,parent,false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.textView.setText(studentList.get(position).getName());
        Glide.with(context).load(studentList.get(position).getPicture()).into(holder.imageView);

    }

    @Override
    public int getItemCount() {
        return 0;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView imageView;
        TextView textView;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView= itemView.findViewById(R.id.firebaseimageviewexampletwo);
            textView= itemView.findViewById(R.id.txtfirebaseexampletwo);

        }
    }
}