package com.example.bsai_6b.FirebaseExamples;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.bsai_6b.R;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class FirebaseExampleOneMainActivity extends AppCompatActivity {
DatabaseReference reference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_firebase_example_one_main);
        FirebaseDatabase database = FirebaseDatabase.getInstance("https://bsai-6b-default-rtdb.firebaseio.com/");
        reference = database.getReference();

        TestUser user= new TestUser();
        user.setName("ALi");
        user.setEmailid("abc@cfd.nu.edu.pk");
        reference.child("BSAI B").setValue(user);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}