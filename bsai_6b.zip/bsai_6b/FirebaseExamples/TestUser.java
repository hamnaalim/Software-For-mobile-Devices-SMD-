package com.example.bsai_6b.FirebaseExamples;

public class TestUser {
    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getEmailid() {
        return Emailid;
    }

    public void setEmailid(String emailid) {
        Emailid = emailid;
    }

    String Name;
    String Emailid;
}
