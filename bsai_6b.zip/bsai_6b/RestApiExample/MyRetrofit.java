package com.example.bsai_6b.RestApiExample;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MyRetrofit {
    // first configure rest api with code
    public static Retrofit retrofit;
    //url of server
    public static String Url="https://jsonplaceholder.typicode.com/";
    // func which connect us with server
    public static Retrofit getConnection(){
        if (retrofit == null)
        {
            //building connectuoin
            retrofit= new Retrofit.Builder()
                    .baseUrl(Url)
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();
        }
        return retrofit;
    }
}
