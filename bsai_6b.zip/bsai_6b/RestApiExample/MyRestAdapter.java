package com.example.bsai_6b.RestApiExample;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.bsai_6b.R;

import java.util.List;

public class MyRestAdapter extends RecyclerView.Adapter<MyRestAdapter.ViewHolder>{
    public MyRestAdapter(List<MyModel> list, Context context) {
        this.list = list;
        this.context = context;
    }

    public List<MyModel> list;
    public Context context;

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater= LayoutInflater.from(parent.getContext());

        View view= inflater.inflate(R.layout.restnewlayout,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.PostId.setText(String.valueOf(list.get(position).getId()));
        holder.PostContent.setText((list.get(position).getBody()));
    }

    @Override
    public int getItemCount() {
        return list.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView PostId,PostContent;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            PostId=itemView.findViewById(R.id.txtpostid);
            PostContent= itemView.findViewById(R.id.txtpostcontent);


        }
    }
}

