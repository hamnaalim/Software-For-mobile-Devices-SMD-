package com.example.bsai_6b.RestApiExample;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;

public interface MyController {
    @GET("posts")
    Call<List<MyModel>> getList();
    @GET("posts/1/comments")
    Call<List<MyCommentsModel>> getCommentsList();
}
