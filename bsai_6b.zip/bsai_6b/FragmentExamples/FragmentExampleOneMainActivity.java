package com.example.FragmentExamples;

import android.content.res.Configuration;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.example.bsai_6b.R;

public class FragmentExampleOneMainActivity extends AppCompatActivity {

    @Override
    // 4 steps i-> configure ii-> fragmentSupport  iii->orientationcheck  iv->commit()
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_fragment_example_one_main);
        //now will do  2 fragmnets attach dynamic way->for landscape,potrait
        //each instant info about phone is in configuration class  -> will ask for configuration class obj
        Configuration configuration=getResources().getConfiguration();
        //fragmentmanager will give support
        FragmentManager fragmentManager=getSupportFragmentManager();
        //fragmnet manager will give us begintransaction
        FragmentTransaction transaction=fragmentManager.beginTransaction();
        if (configuration.orientation== configuration.ORIENTATION_LANDSCAPE)
        {
            LM_Fragmnet lmFragmnet= new LM_Fragmnet();
            //landscape frag lg jaye ga idrr
            transaction.replace(android.R.id.content,lmFragmnet);
        }
        else
        {
            PM_Fragment pmFragment=new PM_Fragment();
            transaction.replace(android.R.id.content, pmFragment);
        }
        transaction.commit();
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}