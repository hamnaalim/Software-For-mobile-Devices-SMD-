package com.example.bsai_6b.CardViewExample;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.bsai_6b.R;

import java.util.List;

public class MyAdapterCardView extends
        RecyclerView.Adapter<MyAdapterCardView.ViewHolder>{
    public Context context;
    //will get model class objects
    public List<MyModelCardView> list;

    public MyAdapterCardView(Context context, List<MyModelCardView> list) {
        this.context = context;
         this.list = list;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.mycard,parent,false);
        return new ViewHolder(view);

        //return null;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        MyModelCardView obj= list.get(position);
        holder.name.setText(obj.getName());
        holder.totalDownloads.setText(String.valueOf(obj.getTotal_Downloads()));
        Glide.with(context).load(obj.getThumbnail()).into(holder.thumbnail);
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        ImageView thumbnail;
        TextView name,totalDownloads;
        public ViewHolder(@Nullable View view)
        {
            super(view);
            name = view.findViewById(R.id.txtcardviewone);
            totalDownloads = view.findViewById(R.id.txtcardviewtwo);
            thumbnail= view.findViewById(R.id.imgcardview);
        }
    }
}
