package com.example.bsai_6b.CardViewExample;

import android.graphics.Rect;
import android.os.Bundle;

import com.google.android.material.appbar.CollapsingToolbarLayout;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.View;

import com.example.bsai_6b.R;
import com.example.bsai_6b.databinding.ActivityMyCardViewMainBinding;

import java.util.ArrayList;
import java.util.List;

public class MyCardViewMainActivity extends AppCompatActivity {

    private ActivityMyCardViewMainBinding binding;
    public List<MyModelCardView> list;
    public MyAdapterCardView adapter;
    public RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMyCardViewMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        Toolbar toolbar = binding.toolbar;
        setSupportActionBar(toolbar);
        CollapsingToolbarLayout toolBarLayout = binding.toolbarLayout;
        toolBarLayout.setTitle(getTitle());

        FloatingActionButton fab = binding.fab;
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null)
                        .setAnchorView(R.id.fab).show();
            }
        });
        recyclerView = findViewById(R.id.cardviewrecyclerview);
        list = new ArrayList<>();
        adapter = new MyAdapterCardView(this, list);

        RecyclerView.LayoutManager layoutManager= new GridLayoutManager(this,2);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.addItemDecoration(new GridSpacingDecoration(2,(12),true));
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(adapter);
        LoadData();
    }


    private class GridSpacingDecoration extends RecyclerView.ItemDecoration

    {
        int count, spacing ;
        boolean EdgeInclude;

        public GridSpacingDecoration(int count, int spacing, boolean edgeInclude) {
            this.count = count;
            this.spacing = spacing;
            EdgeInclude = edgeInclude;
        }

        @Override
        public void getItemOffsets(@NonNull Rect outRect, @NonNull View view, @NonNull RecyclerView parent, @NonNull RecyclerView.State state) {
            int itemPosition = parent.getChildAdapterPosition(view);
            int itemColumn = itemPosition % count;
            if (EdgeInclude)
            {
                outRect.left = spacing - itemColumn * spacing/count;
                outRect.right= (itemColumn+1) * spacing/count;
                if (itemPosition<count)
                {
                    outRect.top= spacing;
                }
                outRect.bottom = spacing ;

            }
        }
    }
    public void LoadData()
    {
        int [] myImages = new int []
                {
                    R.drawable.camera,R.drawable.camera,
                        R.drawable.gimble,R.drawable.gimble,
                        R.drawable.porsche,R.drawable.porsche,
                        R.drawable.yellow,R.drawable.yellow

                };
        MyModelCardView obj = new MyModelCardView("First CardView",8,myImages[0]);
                list.add(obj);
        obj = new MyModelCardView("Second CardView", 8, myImages[1]);
        list.add(obj);
        obj = new MyModelCardView("Third CardView",8,myImages[2]);
        list.add(obj);
        obj = new MyModelCardView("Fourth CardView",8,myImages[3]);
        list.add(obj);
        obj = new MyModelCardView("Third CardView",8,myImages[4]);
        list.add(obj);

        adapter.notifyDataSetChanged();

    }
}