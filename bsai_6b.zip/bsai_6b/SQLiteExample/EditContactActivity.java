package com.example.bsai_6b.SQLiteExample;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.bsai_6b.R;

import java.util.HashMap;

public class EditContactActivity extends AppCompatActivity {
    DbQueries dbQueries;
    EditText id,editTextFirstName,editTextSecondName,editTextPhoneNumber,editTextEmailAddress,editTextHomeAddress;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_edit_contact);
        //main take hash map back->sql->edit
        //main->sql send hash map tp edit
        editTextFirstName=findViewById(R.id.editfirstname);
        editTextSecondName=findViewById(R.id.editsecondname);
        editTextPhoneNumber= findViewById(R.id.editphonenumber);
        editTextEmailAddress=findViewById(R.id.editemailaddress);
        editTextHomeAddress=findViewById(R.id.edithomeaddress);


        dbQueries = new DbQueries(getApplicationContext());
        Intent intent= getIntent();
        String id= intent.getStringExtra("_id");
        HashMap<String,String > hashMap = dbQueries.getSingleRecord(id);
        if(hashMap.size() !=0 )
        {
            editTextFirstName.setText(hashMap.get("firstName"));
            editTextSecondName.setText(hashMap.get("secondName"));
            editTextPhoneNumber.setText(hashMap.get("phoneNumber"));
            editTextEmailAddress.setText(hashMap.get("emailAddress"));
            editTextHomeAddress.setText(hashMap.get("homeAddress"));
        }


        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    public void UpdateContact(View view) {
        //making contactID var to get id so that we can search in database
        String contactID;
        contactID=getIntent().getStringExtra("_id");
        //checking the contraints if these case are possible to handle them
        if (contactID == null || contactID.isEmpty())
        {
            Toast.makeText(this, "Invalid contact id", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!dbQueries.contactExist(contactID))
        {
            Toast.makeText(this, "Contact does not exist", Toast.LENGTH_SHORT).show();
            return;
        }
        //now we will get the data that is updated by user in editcontact activity

        String firstName,secondName,phoneNumber,emailAddress,homeAddress;

        firstName=editTextFirstName.getText().toString();
        secondName=editTextSecondName.getText().toString();
        phoneNumber=editTextPhoneNumber.getText().toString();
        emailAddress=editTextEmailAddress.getText().toString();
        homeAddress=editTextHomeAddress.getText().toString();

        boolean isUpdated = dbQueries.updateContact(contactID, firstName, secondName, phoneNumber, emailAddress, homeAddress);

        if (isUpdated) {
            Toast.makeText(this, "Contact Updated Successfully", Toast.LENGTH_SHORT).show();

            Intent resultIntent = new Intent();
            resultIntent.putExtra("updated", true);
            setResult(RESULT_OK, resultIntent);

            finish();  // Close Edit Activity and go back
        } else {
            Toast.makeText(this, "Update Failed", Toast.LENGTH_SHORT).show();
        }

    }

    public void Deletion(View view) {
        String contactID;
        contactID=getIntent().getStringExtra("_id");
        dbQueries.deleteContact(contactID);

        Intent intent=new Intent();
        intent.putExtra("Delete",true);
        setResult(RESULT_OK,intent);
        finish();
    }
}