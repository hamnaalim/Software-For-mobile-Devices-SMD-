package com.example.bsai_6b.SQLiteExample;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;

public class DbQueries extends SQLiteOpenHelper {

    public DbQueries(Context context)
    {
        super(context,"contactDB",null,1);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        String Query ="CREATE TABLE CONTACTS( "+
                "_id INTEGER PRIMARY KEY AUTOINCREMENT ,"+
                "firstName TEXT , "+
                "secondName TEXT, "+
                "phoneNumber TEXT ,"+
                "emailAddress TEXT ,"+
                "homeAddress TEXT  )";
        db.execSQL(Query);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
    public boolean updateContact(String id, String firstName, String secondName, String phoneNumber, String emailAddress, String homeAddress) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("firstName", firstName);
        values.put("secondName", secondName);
        values.put("phoneNumber", phoneNumber);
        values.put("emailAddress", emailAddress);
        values.put("homeAddress", homeAddress);

        int rowsAffected = db.update("CONTACTS", values, "_id=?", new String[]{id});
        return rowsAffected > 0;
    }

    public boolean contactExist(String id)
    {
        SQLiteDatabase db= this.getReadableDatabase();
        Cursor cursor=db.rawQuery("SELECT * FROM CONTACTS WHERE _id=?", new String[]{id});
        boolean exist= cursor.getCount()>0;
        return exist;
    }
    public void Insert(HashMap<String, String> hashMap) {
        SQLiteDatabase db= getWritableDatabase();
        ContentValues contact = new ContentValues();
        contact.put("_id",hashMap.get("_id"));
        //both keys
        contact.put("firstName",hashMap.get("firstName"));
        contact.put("secondName",hashMap.get("secondName"));
        contact.put("phoneNumber",hashMap.get("phoneNumber"));
        contact.put("emailAddress",hashMap.get("emailAddress"));
        contact.put("homeAddress",hashMap.get("homeAddress"));
        db.insert("CONTACTS",null,contact);
    }
    //arraylist ky hrrr index py aik hashmap pra ho ga
    //fetching data from database
    public ArrayList<HashMap<String,String>> getAllcontacts()
    {
        SQLiteDatabase db = getReadableDatabase();
        ArrayList<HashMap<String,String>> arrayList = new ArrayList<>();

        //writing query for fetching from db
        String Query= "SELECT * FROM CONTACTS";
        //in java curser class help in reading db
        Cursor cursor = db.rawQuery(Query,null);
        if (cursor.moveToFirst())
        {
            do {
                HashMap<String,String> hashMap = new HashMap<>();
                hashMap.put("_id",cursor.getString(0));
                hashMap.put("firstName",cursor.getString(1));
                hashMap.put("secondName",cursor.getString(2));
                hashMap.put("phoneNumber",cursor.getString(3));
                hashMap.put("emailAddress",cursor.getString(4));
                hashMap.put("homeAddress",cursor.getString(5));
                arrayList.add(hashMap);
            }
            while(cursor.moveToNext());
        }
        return arrayList;
    }

    public HashMap<String,String> getSingleRecord(String id) {
        SQLiteDatabase db= getReadableDatabase();
        HashMap<String,String > hashMap = new HashMap<>();
        String Query = "SELECT * FROM CONTACTS WHERE _id="+id;
        Cursor cursor= db.rawQuery(Query,null);
        // to check if there is somethign in db
        if (cursor.moveToFirst())
        {
            hashMap.put("_id",cursor.getString(0));
            hashMap.put("firstName",cursor.getString(1));
            hashMap.put("secondName",cursor.getString(2));
            hashMap.put("phoneNumber",cursor.getString(3));
            hashMap.put("emailAddress",cursor.getString(4));
            hashMap.put("homeAddress",cursor.getString(5));
        }
        return hashMap;
    }

    public void deleteContact(String id) {
        SQLiteDatabase db=this.getWritableDatabase();
        db.delete("CONTACTS","_id = ?", new String[]{id});

        db.close();
    }
}
