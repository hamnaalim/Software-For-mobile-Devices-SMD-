package com.example.bsai_6b.SQLiteExample;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import androidx.activity.EdgeToEdge;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.bsai_6b.R;

import java.util.ArrayList;
import java.util.HashMap;

public class MainActivitySQlite extends AppCompatActivity {
    ListView listview;
    DbQueries dbQueries;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main_sqlite);

        listview= findViewById(R.id.lstmaincontactlist);

        dbQueries = new DbQueries(getApplicationContext());
        ArrayList<HashMap<String,String>> contactlist = dbQueries.getAllcontacts();
        SimpleAdapter adapter = new SimpleAdapter(this,
                contactlist,R.layout.allcontactslayout,
                new String[]{"_id","firstName","secondName"},
                new int[]{R.id.textViewID,R.id.textViewFirstName,R.id.textViewLastName}
        );
        listview.setAdapter(adapter);

        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent((MainActivitySQlite.this), EditContactActivity.class);
                intent.putExtra("_id",String.valueOf(id+1));
                startActivityForResult(intent,3);
            }
        });


        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if ((requestCode == 2 || requestCode==3) && resultCode == RESULT_OK) {
            refreshContactList();
        }
    }

    public void AddContact(View view) {
        Intent intent = new Intent(this, NewContactEntery.class);
        //it take into new contact entry

        startActivityForResult(intent, 2);
    }
    public void refreshContactList()
    {
        ArrayList<HashMap<String,String>> updatedcontactlist = dbQueries.getAllcontacts();
        SimpleAdapter adapter = new SimpleAdapter(this,
                updatedcontactlist,R.layout.allcontactslayout,
                new String[]{"_id","firstName","secondName"},
                new int[]{R.id.textViewID,R.id.textViewFirstName,R.id.textViewLastName}
        );
        listview.setAdapter(adapter);
        adapter.notifyDataSetChanged();
    }


}