package com.example.bsai_6b.RestApiExample;

import android.os.Bundle;
import android.util.Log;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.bsai_6b.R;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
public class RestApiExampleMainActivity extends AppCompatActivity {
    MyController controller;
    RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_rest_api_example_main);
        recyclerView= findViewById(R.id.restapirecyclerview);
        controller= MyRetrofit.getConnection().create(MyController.class);
        //Getlist();
        GetComments();

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    private void GetComments() {
        Call<List<MyCommentsModel>> list = controller.getCommentsList(6);
        list.enqueue(new Callback<List<MyCommentsModel>>() {
            @Override
            public void onResponse(Call<List<MyCommentsModel>> call, Response<List<MyCommentsModel>> response) {
                if (response.isSuccessful()){
                    for (MyCommentsModel comments : response.body()){
                        Log.d("TAG", "  ID " + comments.getId() + "Postid"+ comments.getPostId() +" User name  " + comments.getName() +
                                " Email " + comments.getEmail() + " Body " + comments.getBody());
                        Log.d("TAG", "Data Received ");
                    }
                }
            }

            @Override
            public void onFailure(Call<List<MyCommentsModel>> call, Throwable t) {

            }
        });
    }

    private void Getlist() {
        controller.getList().enqueue(new Callback<List<MyModel>>() {
            @Override
            public void onResponse(Call<List<MyModel>> call, Response<List<MyModel>> response) {
                if (response.body().size()> 0){
                    //  Log.d("TAG", "Data Received ");
                    List<MyModel> list= response.body();
                    MyRestAdapter adapter= new MyRestAdapter(list, RestApiExampleMainActivity.this);
                    LinearLayoutManager layoutManager= new LinearLayoutManager(RestApiExampleMainActivity.this);
                    recyclerView.setLayoutManager(layoutManager);
                    recyclerView.setAdapter(adapter);



                }
            }

            @Override
            public void onFailure(Call<List<MyModel>> call, Throwable t) {

            }
        });
    }
}