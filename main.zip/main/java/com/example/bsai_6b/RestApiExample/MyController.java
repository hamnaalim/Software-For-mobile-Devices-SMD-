package com.example.bsai_6b.RestApiExample;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;

public interface MyController {
    @GET("posts")
    Call<List<MyModel>> getList();
    @GET("posts/{id}/comments")
    Call<List<MyCommentsModel>> getCommentsList(@Path("id") int id);

}
