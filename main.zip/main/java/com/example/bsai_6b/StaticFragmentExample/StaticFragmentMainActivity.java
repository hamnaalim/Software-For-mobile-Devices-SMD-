package com.example.bsai_6b.StaticFragmentExample;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.bsai_6b.R;

public class StaticFragmentMainActivity extends AppCompatActivity implements ContactsFragment.ListSelectionListener{
    public static String[] contactsArray;
    public static String[] contactsDetailArray;
    ContactsDetails obj;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_static_fragment_main);
        contactsArray=getResources().getStringArray(R.array.contacts);
        contactsDetailArray=getResources().getStringArray(R.array.contactsdetails);
        //obj=getSupportFragmentManager().findFragmentById(R.id.txtcontactdetail);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    @Override
    public void onSelection(int position) {

        if(obj.getCurrentIndex() != position)
        {
            obj.contactIndex(position);
        }
    }


}