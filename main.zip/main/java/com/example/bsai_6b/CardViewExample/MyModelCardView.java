package com.example.bsai_6b.CardViewExample;


public class MyModelCardView {
    public String Name;
    public int Total_Downloads;
    public int Thumbnail;

    public MyModelCardView(String name, int total_Downloads, int thumbnail) {
        Name = name;
        Total_Downloads = total_Downloads;
        Thumbnail = thumbnail;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public int getTotal_Downloads() {
        return Total_Downloads;
    }

    public void setTotal_Downloads(int total_Downloads) {
        Total_Downloads = total_Downloads;
    }

    public int getThumbnail() {
        return Thumbnail;
    }

    public void setThumbnail(int thumbnail) {
        Thumbnail = thumbnail;
    }
}