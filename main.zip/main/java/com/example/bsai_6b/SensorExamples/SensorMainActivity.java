package com.example.bsai_6b.SensorExamples;

import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.bsai_6b.R;

public class SensorMainActivity extends AppCompatActivity implements SensorEventListener {
SensorManager sensorManager;
TextView textView;
View view;
boolean color= false;
long recentTime;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_sensor_main);
        textView= findViewById(R.id.txtsensorvalue);
        view= findViewById(R.id.main);
        // systems ka current time
        recentTime= System.currentTimeMillis();
        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    @Override
    //sensor ki value change ho gio tp us ethis
    public void onSensorChanged(SensorEvent event)
    {
            if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER)
            {
                sensorValues(event);
            }
    }

    @Override

    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }

    public void sensorValues(SensorEvent event)
    {
        //will check if x,y and z changes means tjhat mobile is moving
        float[] values = event.values;
        float x= values[0];
        float y= values[1];
        float z= values[2];
        float acceleration = (x*x + y*y + z*z)/ SensorManager.GRAVITY_EARTH * SensorManager.GRAVITY_EARTH;
        //time when sensor calls
        long currentTime= event.timestamp;

        if (acceleration > 2)
        {
            if (currentTime - recentTime  < 30)
            {
                return;
            }
            recentTime=currentTime;
            textView.setText("Mobile was moved ");
            if (color)
            {
                view.setBackgroundColor(Color.BLUE);
            }
            else
            {
                view.setBackgroundColor(Color.GREEN);

            }
            color= true;
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        sensorManager.registerListener(this,sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER),SensorManager.SENSOR_DELAY_NORMAL);
    }

    @Override
    protected void onPause() {
        super.onPause();
        sensorManager.unregisterListener(this);
    }
}